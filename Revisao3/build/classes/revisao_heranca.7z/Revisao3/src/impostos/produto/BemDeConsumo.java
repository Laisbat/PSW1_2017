package impostos.produto;

import java.util.Date;

public class BemDeConsumo extends Produto {
	private Date vencimento;

	public Date getVencimento() {
		return vencimento;
	}

	public void setVencimento(Date vencimento) {
		this.vencimento = vencimento;
	}

	
	
}

package impostos.produto;

public class BemDeCapital extends Produto {
	private int anosGarantia;

	public int getAnosGarantia() {
		return anosGarantia;
	}

	public void setAnosGarantia(int anosGarantia) {
		this.anosGarantia = anosGarantia;
	}
}
